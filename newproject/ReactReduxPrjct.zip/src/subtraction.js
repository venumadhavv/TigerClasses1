// import {useSelector,useDispatch} from 'react-redux'

// const sub=()=>{
//   return{
//     type:'SUB'
//   }
// }

// export function Subtract() {
//   const num=useSelector((state)=>state.reducerFunction);
//   const dispatch=useDispatch();
//   return (

//     <div >
//       <h1>{num}</h1>
//       <button onClick={()=>{dispatch(sub())}}>Sub</button>


//     </div>
//   );
// }

