import { useSelector } from "react-redux";
 function Result(){
    const result =useSelector((state)=>state.reducerFunction);
    return(<h1>Result:{result}</h1>)
}
export default Result;