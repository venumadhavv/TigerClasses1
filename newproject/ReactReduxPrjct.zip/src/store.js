import { combineReducers,createStore } from "redux";

const result=0;

function reducerFunction(state=result,action){
    if(action.type==='ADD')
            return action.payload['num1']+action.payload['num2'];
   
    else
            return state;
}

const root=combineReducers({reducerFunction});
export const store=createStore(root);