import {useDispatch} from 'react-redux'
var num1,num2;
const add=()=>{
  return {
  type:'ADD',
  payload:{num1,num2}
}
}
function setValue1(e){
  num1=Number(e.target.value);
}
function setValue2(e){
  num2=Number(e.target.value);
}

 function Add(){
  const dispatch=useDispatch();
  return(
    <div className="App">
        <input id="num1"type="text" onChange={setValue1} placeholder="First Number"/>
        <input id="num2"type="text" onChange={setValue2} placeholder="Second Number"/>
        <button onClick={()=>{dispatch(add())}}>Add</button>
    </div>
  );
}
export default Add;