import './App.css';
import  Add  from './additon';
import  Result from './Result';
function App() {
  return (

    <div className="App">
      <Add/>
      <Result/>
    </div>
  );
}

export default App;
